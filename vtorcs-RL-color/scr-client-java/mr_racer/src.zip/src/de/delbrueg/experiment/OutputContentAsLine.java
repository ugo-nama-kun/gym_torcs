/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.delbrueg.experiment;

/**
 *
 * @author Tim
 */
public interface OutputContentAsLine {

    public String getContentAsLine(String seperator);
    public String getContentHeadLine(String seperator);
}
