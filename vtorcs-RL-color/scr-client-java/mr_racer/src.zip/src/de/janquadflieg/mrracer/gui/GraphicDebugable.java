/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.janquadflieg.mrracer.gui;

/**
 *
 * @author Jan Quadflieg
 */
public interface GraphicDebugable {

    public javax.swing.JComponent[] getComponent();

}
