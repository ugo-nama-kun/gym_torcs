/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.janquadflieg.mrracer.data;

/**
 *
 * @author quad
 */
public interface CarConstants {
    public static final double CAR_WIDTH = 2.2;
    public static final double CAR_LENGTH = 5.0;
}
